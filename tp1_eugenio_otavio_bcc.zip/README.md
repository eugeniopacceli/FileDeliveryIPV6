# FileDeliveryIPV6

C++ implementation of a IPV6 file server and client, capable of listing directories and transferring files.

# Compiling

Navigate to the project folder and type "make", the client and server binaries will be available at the "bin/ folder"

# Running

To run both the client and the server, follow the orientations specified in TP1.pdf

# Authors

Eugênio Pacceli & Otávio Augusto, DCC/UFMG